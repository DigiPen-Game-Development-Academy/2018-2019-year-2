﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

 [RequireComponent(typeof(Rigidbody))]
public class Player : MonoBehaviour
{
    new Rigidbody rigidbody;
    public Camera mouseCamera;

    // Fine tuning variables
    public float acceleration = 3;
    public float speed = 2;
    public float turnSpeed = 3;
    public float firerate = 0.1f;
    public GameObject projectile;

    // Non editable variables
    float secondsTillFire = 0;
    int shootingMode = 0;

    // Use this for initialization
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    GameObject Shoot(Vector3 pos, Vector3 dir)
    {
        // Reset cooldown
        secondsTillFire = firerate;

        Quaternion rot = Quaternion.FromToRotation(Vector3.up, dir);

        // Create the projectile
        GameObject created = Instantiate(projectile, pos + dir * 2, rot);

        created.GetComponent<Projectile>().direction = dir;

        return gameObject;
    }

    void ShootForward()
    {
        // Countdown until we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            Shoot(transform.position, transform.forward);
        }
    }
    void ShootForwardBack()
    {
        // Countdown until we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            Shoot(transform.position, transform.forward);
            Shoot(transform.position, -transform.forward);
        }
    }
    void ShootLeftRight()
    {
        // Countdown until we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            Shoot(transform.position, transform.right);
            Shoot(transform.position, -transform.right);
        }
    }
    void ShootAllDirections()
    {
        // Countdown until we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            Shoot(transform.position, transform.right);
            Shoot(transform.position, -transform.right);
            Shoot(transform.position, transform.forward);
            Shoot(transform.position, -transform.forward);
        }
    }
    void ShootMouse()
    {

        Vector3 target = Input.mousePosition;
        target.z = mouseCamera.transform.position.y;
        target = mouseCamera.ScreenToWorldPoint(target);
        Shoot(transform.position, (target - transform.position).normalized);

    }
    // Update is called once per frame
    void Update()
    {
        // Create a storage variable for input
        Vector3 input = Vector3.zero;

        // Gather the input from the keyboard
        if (Input.GetKey(KeyCode.W)) input.z += 1;
        if (Input.GetKey(KeyCode.S)) input.z += -1;
        if (Input.GetKey(KeyCode.A)) input.x += -1;
        if (Input.GetKey(KeyCode.D)) input.x += 1;

        // Convert the input to world coordinates
        // so that the player moves in the direction they are facing 
        // instead of on the cardinal world directions
        //input = transform.TransformDirection(input) * speed;

        // Combine the horizontal input velocity
        // with the vertical velocity we already have
        Vector3 velocity = new Vector3(input.x, rigidbody.velocity.y, input.z) * speed;

        // Apply the velocity to the player
        rigidbody.velocity = Vector3.Lerp(rigidbody.velocity, velocity, acceleration * Time.deltaTime);


        // Disallow the player from getting spun by physics
        rigidbody.maxAngularVelocity = 0;

        Vector3 target = Input.mousePosition;
        target.z = mouseCamera.transform.position.y - transform.position.y;
        target = mouseCamera.ScreenToWorldPoint(target);
        transform.rotation = Quaternion.LookRotation(target - transform.position, Vector3.up);

        // Gathering input do determing shooting mode
        if (Input.GetKey(KeyCode.Alpha1)) shootingMode = 1;
        if (Input.GetKey(KeyCode.Alpha2)) shootingMode = 2;
        if (Input.GetKey(KeyCode.Alpha3)) shootingMode = 3;
        if (Input.GetKey(KeyCode.Alpha4)) shootingMode = 4;

        // Check players input and then use the correct shooting mode
        switch(shootingMode)
        {
            case 1:
                ShootForward();
                break;
            case 2:
                ShootForwardBack();
                break;
            case 3:
                ShootLeftRight();
                break;
            case 4:
                ShootAllDirections();
                break;
            default:
                ShootForward();
                break;
        }
    }
}

