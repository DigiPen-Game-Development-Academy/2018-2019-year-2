﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonCamera : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        transform.position = new Vector3(transform.parent.position.x, transform.parent.position.y + 0.5f, transform.parent.position.z);
        transform.rotation = transform.parent.rotation;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
