﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

 [RequireComponent(typeof(Rigidbody))]
public class Player : MonoBehaviour
{
    new Rigidbody rigidbody;

    // Fine tuning variables
    public float acceleration = 3;
    public float speed = 2;
    public float turnSpeed = 3;
    public float firerate = 0.1f;
    public GameObject projectile;

    // Non editable variables
    float secondsTillFire = 0;

    // Use this for initialization
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        // Create a storage variable for input
        Vector3 input = Vector3.zero;

        // Gather the input from the keyboard
        if (Input.GetKey(KeyCode.W)) input.z += 1;
        if (Input.GetKey(KeyCode.S)) input.z += -1;
        if (Input.GetKey(KeyCode.A)) input.x += -1;
        if (Input.GetKey(KeyCode.D)) input.x += 1;

        // Convert the input to world coordinates
        // so that the player moves in the direction they are facing 
        // instead of on the cardinal world directions
        input = transform.TransformDirection(input) * speed;

        // Combine the horizontal input velocity
        // with the vertical velocity we already have
        Vector3 velocity = new Vector3(input.x, rigidbody.velocity.y, input.z);

        // Apply the velocity to the player
        rigidbody.velocity = Vector3.Lerp
            (rigidbody.velocity, velocity, acceleration * Time.deltaTime);

        // Disallow the player from getting spun by physics
        rigidbody.maxAngularVelocity = 0;

        // Rotate the player using the mouse input instead of physics
        transform.Rotate(Vector3.up, Input.GetAxis("Mouse X") * turnSpeed);

        // Countdown until we can fire
        secondsTillFire -= Time.deltaTime;
        // Check for input and cooldown
        if (Input.GetMouseButton(0) && secondsTillFire <= 0)
        {
            // Reset cooldown
            secondsTillFire = firerate;

            // Create the projectile
            GameObject created = Instantiate(projectile,
                transform.position + transform.forward * 2, transform.rotation * Quaternion.Euler(90, 0, 0));

            // Launch the projectile


        }
    }
}
